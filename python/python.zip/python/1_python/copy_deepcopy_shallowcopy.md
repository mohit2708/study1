|  No.  | [Questions](../0.0_python_questions.md)                                                                              |
| :---: | -------------------------------------------------------------------------------------------------------------------- |
|       | [Copy Object](#copy-of-object)                                                                                       |
|       | [Using Equal(=) Oprater](#copy-object-using-equal-oprater)                                                           |
|       | [Using Deep Copy](#copy-object-using-deep-copy)                                                                      |
|       | [Using shallow Copy](#copy-object-using-shallow-copy)                                                                |
|       | [Difference between Deep Copy and Shallow Copy in Python?](#difference-between-deep-copy-and-shallow-copy-in-python) |

# Copy Of Object
### **Copy Object Using Equal(=) Oprater**
* In Python, we use **= operator** to create a copy of an object. It only creates a new variable that shares the reference of the original object.
* When we make any **changes** to a copy **of** an **object**, those changes **do reflect** in the original object **because** it creates a new object that **stores** the **references** of the **original** elements.
```python
old_list = [[1, 2, 3], [4, 5, 6], [7, 8, 'a']]
new_list = old_list

new_list[2][2] = 9

print('Old List:', old_list) # output:- Old List: [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print('New List:', new_list) # Output:- New List: [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
```

### **Copy object Using Deep Copy**
* In deep copy, When we make any changes to a copy of an object, those changes **do not reflect** in the **original object**.
* Deep copying in Python ensures that the copy is a completely independent object, with **no** shared **references** to the **original object** or its nested components. This is why changes made to a deep copy do not reflect in the original object.

```python
import copy

old_list = [[1, 1, 1], [2, 2, 2], [3, 3, 3]]
new_list = copy.deepcopy(old_list)

new_list[1][0] = 'BB'

print("Old list:", old_list)
print("New list:", new_list)

Output:- 
Old list: [[1, 1, 1], [2, 2, 2], [3, 3, 3]]
New list: [[1, 1, 1], ['BB', 2, 2], [3, 3, 3]]
```
<div style="page-break-before: always;"></div>

### **Copy object Using Shallow copy**
* A shallow copy creates a new object which **stores** the **reference** of the **original elements**.
* When we make any changes to a copy of an object, those **changes** do reflect in the **original object** because it creates a new object that **stores** the **references** of the **original elements.**
```python
import copy

old_list = [[1, 1, 1], [2, 2, 2], [3, 3, 3]]
new_list = copy.copy(old_list)

new_list[1][1] = 'AA'

print("Old list:", old_list)
print("New list:", new_list)

Output:- 
Old list: [[1, 1, 1], [2, 'AA', 2], [3, 3, 3]]
New list: [[1, 1, 1], [2, 'AA', 2], [3, 3, 3]]
```

### **Difference between Deep Copy and Shallow Copy in Python?**
|                                               Shallow Copy                                               |                                            Deep Copy                                             |
| :------------------------------------------------------------------------------------------------------: | :----------------------------------------------------------------------------------------------: |
| Creates a new object with a new reference, but the content is the same reference as the original object. | Creates a new object with a new reference, and the content is a new copy of the original object. |
|                Shares reference to original object, changes to copy affects the original.                |        Independent from the original object, changes to copy do not affect the original.         |
|                             Only copies the top-level elements of an object.                             |                               Copies all levels of nested objects.                               |
|                Memory-efficient, as it doesn’t create new objects for nested references.                 |                Memory-intensive, as it creates new objects for nested references.                |
|                 Fast operation, as it doesn’t create new objects for nested references.                  |                 Slow operation, as it creates new objects for nested references.                 |
