|  No.  | [Basic steps]()                                                             |
| :---: | --------------------------------------------------------------------------- |
|       | [Install Python?](#install-python)                                          |
|       | [Check version of Python?](#check-version-of-python)                        |
|       | [Check version of pip?](#check-version-of-pip)                              |
|       | [Create virtual enviroment?](#create-virtual-enviroment)                    |
|       | [How to check which packages install](#how-to-check-which-packages-install) |
|       | [Activated virtual enviroment?](#activated-virtual-enviroment)              |

### Install Python
* Install Python https://www.python.org/downloads/

### Check version of Python
```python
python --version (OR) py -V
```

### Check version of pip
```python
pip --version
```

### How to check which packages install
* note:- after create virtual environment not activate.
```python
pip freeze
```

### Create virtual enviroment
* create the folder and open the cmd
```python
python -m venv virtual-name
OR
pip install virtualenv  # Install the package.
virtualenv MyFirstApp
MyFirstApp\scripts\activate
```

### Activated virtual enviroment
```pyhton
cd virtual-name\Scripts
d:\mohit\virtual-name\Scripts> activate
```

