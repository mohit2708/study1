|  No.  | [Mysql Connectivity](./1.3_mysql_connectivity.md)            |
| :---: | ------------------------------------------------------------ |
|       | [MySQL Database Connectivity?](#mysql-database-connectivity) |

### MySQL Database Connectivity
```python
firstly we create the database in mysql
```
* Install the package:- 
```python
pip install mysqlclient
```
In setting.py
```python
Update the connection string.
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'database_name',
        'USER': 'mysql_user',
        'PASSWORD': 'mysql_password',
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'"
            
         }
    }
}
```
```python
python manage.py migrate
```